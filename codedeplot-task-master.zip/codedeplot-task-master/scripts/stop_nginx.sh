#!/bin/bash
sudo docker stop nginx-tomer
sudo docker rm nginx-tomer
